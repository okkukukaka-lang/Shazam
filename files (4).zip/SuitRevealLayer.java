package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Animasi ganti kostum. Saat berubah, kostum terbentuk bagian demi bagian di atas kulit asli:
 * dada dulu, lalu lengan, kepala, dan kaki, dengan kilau emas yang menyapu tiap bagian.
 * Saat kembali jadi manusia, kostum luruh dengan urutan terbalik.
 */
public class SuitRevealLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SHIMMER = ResourceLocation.withDefaultNamespace("textures/entity/creeper/creeper_armor.png");
    private static final int[] DELAY_IN = {0, 2, 4, 5};   // badan, lengan, kepala, kaki
    private static final int[] DELAY_OUT = {5, 3, 1, 0};
    private static final float FADE = 5f;

    public SuitRevealLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    private static ModelPart[] group(PlayerModel<AbstractClientPlayer> m, int index) {
        return switch (index) {
            case 0 -> new ModelPart[] {m.body, m.jacket};
            case 1 -> new ModelPart[] {m.rightArm, m.rightSleeve, m.leftArm, m.leftSleeve};
            case 2 -> new ModelPart[] {m.head, m.hat};
            default -> new ModelPart[] {m.rightLeg, m.rightPants, m.leftLeg, m.leftPants};
        };
    }

    /** 0-1: seberapa jauh bagian ini sudah terbentuk (atau luruh). */
    private static float progress(float t, boolean in, int index) {
        return Mth.clamp((t - (in ? DELAY_IN[index] : DELAY_OUT[index])) / FADE, 0f, 1f);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        float t = ShazamPoses.suitTicks(player, partialTick);
        if (t < 0f || player.isInvisible() || !ShazamSuit.hasSuitTexture()) {
            return;
        }
        boolean in = ShazamPoses.suitIn(player);
        PlayerModel<AbstractClientPlayer> model = this.getParentModel();

        // Tahap 1: kostum dengan transparansi per bagian (satu buffer dulu sampai selesai)
        VertexConsumer suit = buffer.getBuffer(RenderType.entityTranslucent(ShazamSuit.SUIT));
        for (int g = 0; g < 4; g++) {
            float p = progress(t, in, g);
            float alpha = in ? p : 1f - p;
            if (alpha <= 0.01f) {
                continue;
            }
            int color = ((int) (alpha * 255f) << 24) | 0xFFFFFF;
            for (ModelPart part : group(model, g)) {
                part.render(poseStack, suit, packedLight, OverlayTexture.NO_OVERLAY, color);
            }
        }

        // Tahap 2: kilau emas di bagian yang sedang berganti
        float scroll = ageInTicks * 0.02f;
        VertexConsumer shimmer = buffer.getBuffer(RenderType.energySwirl(SHIMMER, scroll % 1f, (scroll * 0.5f) % 1f));
        for (int g = 0; g < 4; g++) {
            float glow = Mth.sin(progress(t, in, g) * Mth.PI);
            if (glow <= 0.05f) {
                continue;
            }
            int color = 0xFF000000 | ((int) (255 * glow) << 16) | ((int) (200 * glow) << 8) | (int) (70 * glow);
            for (ModelPart part : group(model, g)) {
                part.render(poseStack, shimmer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, color);
            }
        }
    }
}
